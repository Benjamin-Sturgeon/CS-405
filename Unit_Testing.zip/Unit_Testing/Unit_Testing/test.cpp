// This is the main testing file
// Benjamin Sturgeon
// March 29 2025

#include "pch.h"

// The global test environment setup and tear down.
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // Initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // Create a smart point to hold the collection.
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // Create a new collection to be used in the test.
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {   // erase all elements in the collection, if any remain.
        collection->clear();
        // free the pointer.
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection.
    void add_entries(int count)
    { //I had to change the function slightly by introducing an IF statement instead of using assert 
        if (count > 0)
        {
            for (auto i = 0; i < count; ++i)
            {
                collection->push_back(rand() % 100);
            }
        }
    }
};

// I added a structure to instatiate my parameterized tests 
struct ParameterizedCollectionTest : CollectionTest, ::testing::WithParamInterface<int>
{
    ParameterizedCollectionTest() {}
};

INSTANTIATE_TEST_CASE_P(CollectionSizes, ParameterizedCollectionTest, ::testing::Values(0, 1, 5, 10));


/// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called

 // This tests that the collection smart pointert is not null
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //    FAIL();
 //}

 // Here I created a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyCollection)
{
    // is the collection empty?
    EXPECT_TRUE(collection->empty()); //I use the google test EXPECT functionality rather than C++ methods

    // if empty, the size must be 0
    EXPECT_EQ(collection->size(), 0);

    // Now I add one element to the collection which should pass tests if successfull
    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty()); //Google Test ASSERT functionality

    // if not empty, what must the size be?
    // size must be 1 because one element addded
    ASSERT_EQ(collection->size(), 1);
}

// Here I create a test to verify adding five values to an empty collection.
TEST_F(CollectionTest, CanAddFiveValuesToCollection)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // Now I add five values to the empty collection
    add_entries(5);

    // I test to make sure collection is not empty
    ASSERT_FALSE(collection->empty());

    // Now I test to make sure collection has 5 values
    ASSERT_EQ(collection->size(), 5);
}

// Here I create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries.
TEST_P(ParameterizedCollectionTest, MaxSizeGreaterThanSize)
{
    // I test that collection is empty. ****
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // I add the values determined by the parameter test
    add_entries(GetParam());

    // Now I make sure that the collection size matches the parameter
    ASSERT_EQ(collection->size(), GetParam());

    // The collection max size should still be greater than the current size
    ASSERT_GT(collection->max_size(), collection->size());
}

// Here I test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_P(ParameterizedCollectionTest, CapacityGreaterThanOrEqualToSize)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // I add the values determined by the parameter test
    add_entries(GetParam());

    // Now I make sure that the collection size matches the parameter
    ASSERT_EQ(collection->size(), GetParam());

    // The collection max capacity should still be greater than the current size
    ASSERT_GE(collection->capacity(), collection->size());
}

// Here I test to verify resizing increases the collection.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // collection is resized to 5
    collection->resize(5);

    // I verify that size was successfully resized
    ASSERT_EQ(collection->size(), 5);
}

// Here I test to verify resizing decreases the collection.
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // I add five entries
    add_entries(5);

    // collection should not be empty
    EXPECT_FALSE(collection->empty());

    // collection should have size of five
    EXPECT_EQ(collection->size(), 5);

    // I resize to 3
    collection->resize(3);

    // Now I make sure collection size is 3
    ASSERT_EQ(collection->size(), 3);
}

// Here I test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeCollectionSizeToZero)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // I add five entries
    add_entries(5);

    // I make sure collection is no longer empty
    EXPECT_FALSE(collection->empty());

    // collection should be five in size
    EXPECT_EQ(collection->size(), 5);

    // I attempt resizing to zero
    collection->resize(0);

    // the size should now be zero due to resize
    ASSERT_EQ(collection->size(), 0);
}

// Here I test to verify clear erases the collection
TEST_F(CollectionTest, ClearCollection)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // Add five elements to the collection.
    add_entries(5);

    // collection should not be empty
    EXPECT_FALSE(collection->empty());

    // collection should have size of 5
    EXPECT_EQ(collection->size(), 5);

    // Now I use the clear method
    collection->clear();

    // collection should now be empty
    ASSERT_TRUE(collection->empty());

    //Since collection is empty, size should be zero
    ASSERT_EQ(collection->size(), 0);
}

// Here I test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseCollection)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // I add five entries to test erase
    add_entries(5);

    // collection should not be empty now that 5 entries have been added
    EXPECT_FALSE(collection->empty());

    // size of collection should be five
    EXPECT_EQ(collection->size(), 5);

    // I call the method to empty the collection from begining to end (entire collection)
    collection->erase(collection->begin(), collection->end());

    // colelction should be empty now
    ASSERT_TRUE(collection->empty());

    // collection now empty so size should be 0
    ASSERT_EQ(collection->size(), 0);
}

// Here I test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreaseCollectionCapacity)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // if the collectin is empty the capacity should be zero
    EXPECT_EQ(collection->capacity(), 0);

    // Use reserve to increase the collection capacity.
    collection->reserve(5);

    // I confirm the collection is stil technically empty
    ASSERT_TRUE(collection->empty());

    // collection size should still be zero
    ASSERT_EQ(collection->size(), 0);

    // Now I test to make sure that capacity is now greater than size
    ASSERT_GT(collection->capacity(), collection->size());
}

// Here I test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRangeExceptionThrown)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // An out of range exception should be thrown
    ASSERT_THROW(collection->at(5), std::out_of_range);
}

// I created a test to confirm that assign works as expected when adding values to the collection
// This is my positive test
TEST_F(CollectionTest, AssignValuesToCollection)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    collection->assign(3, 100);

    // test again to make sure collection is now no longer empty
    ASSERT_FALSE(collection->empty());

    // I test that collection size is 3.
    ASSERT_EQ(collection->size(), 3);

    //I also test that all of the added values are the expected 100
    for (int i = 0; i < 3; i++)
    {
        ASSERT_EQ(collection->at(i), 100);
    }
}

// I also to chose to create a test test to make sure that the reseerve fails to be larger than the max size
// NOTE: This is a negative test
TEST_F(CollectionTest, IncreaseCollectionReserveAboveMaxSize)
{
    // First I test to make sure the collection is empty
    EXPECT_TRUE(collection->empty());

    // if collection is empty size should be 0
    EXPECT_EQ(collection->size(), 0);

    // An error should be thrown if the reserve attempt exceeds the max size
    ASSERT_THROW(collection->reserve(collection->max_size() + 10), std::length_error);
}